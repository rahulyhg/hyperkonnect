<?php

define("siteName", "HyperConnect");
define("URL", "http://localhost/hyper/");

define("server", "localhost");
define("username", "root");
define("password", "");
define("db", "hyperKonnect");



?>