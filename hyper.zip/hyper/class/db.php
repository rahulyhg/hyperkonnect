<?php

include_once("constant.php");

		class db{
			
		public $connections;
		public $last;
			
		public function __construct(){
			
			$this->connections = new mysqli(server, username, password, db);
			
			if (mysqli_connect_error()){
				echo "An error occured ".mysqli_connect_error();
				exit();
				}
			 
			}	
			
		 public function runQuery($data){
		 
		if (!$result = $this->connections->query($data)){
			trigger_error("AN ERROR OCCURED. ".$this->connections->error, E_USER_ERROR);
			}
			else {
			$this->last = $result;	
			return true;
				}
			}
			
	 public function numRows() {
        return $this->last->num_rows;
    }		
		
	 public function getData() {
        return $this->last->fetch_array(MYSQLI_ASSOC);
    }
		
		
		 public function cleanData($value) {
        // Stripslashes
        if (get_magic_quotes_gpc()) {
            $value = stripslashes($value);
        }
        // Quote value
        if (version_compare(phpversion(), "4.3.0") == "-1") {
            $value = $this->connections->escape_string($value);
        } else {
            $value = $this->connections->real_escape_string($value);
        }
        return $value;
    }

		
		
			
			}

?>